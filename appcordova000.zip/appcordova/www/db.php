<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id12789031_localhost","123123","id12789031_akademik") or die ("could not connect database");
?>